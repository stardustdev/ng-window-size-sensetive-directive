export interface IConfig {
  mobile: number;
  tablet: number;
}
